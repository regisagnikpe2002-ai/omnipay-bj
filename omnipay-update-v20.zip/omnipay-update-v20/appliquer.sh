#!/bin/bash
# OMNIPAY v20 — Gestionnaire de fonds & risque (OMNICHECK). À lancer DEPUIS le dossier omnipay-bj.
set -e
echo "OMNIPAY — paquet v20 (gestionnaire de fonds & risque)"
SRC="$(cd "$(dirname "$0")" && pwd)/files"
if [ ! -f server.js ] || [ ! -d routes ] || [ ! -d public ] || [ ! -d lib ]; then echo "ERREUR : lancez ce script depuis le dossier omnipay-bj."; exit 1; fi
echo "1/5 Synchronisation avec GitHub…"; git pull --rebase --autostash origin main
echo "2/5 Contrôle des fichiers locaux…"
bad=0
chkhash(){ cur="$(git hash-object "$1" 2>/dev/null || echo absent)"; if [ "$cur" = "$2" ]; then echo "   OK    $1"; else echo "   DIFFÉRENT $1 (modifié depuis la préparation de ce paquet)"; bad=1; fi; }
chkhash server.js bccb949ec3f5024cbffae3f39ab309bdc929de83
chkhash routes/walletOps.js 3d5dfdb28b0df7b50b0514926bf8ff05e50374ce
chkhash public/omnicheck.html 25052e4132c618514fedbfe6d12f704561656292
if [ "$bad" = 1 ]; then echo "ARRÊT : un fichier a changé. Rien n'a été copié : envoyez-moi cet écran pour que je fusionne sans rien écraser."; exit 1; fi
echo "3/5 Copie des fichiers…"
BK="_sauvegarde_avant_v20"; mkdir -p "$BK"
(cd "$SRC" && find . -type f) | while read -r f; do if [ -f "$f" ]; then mkdir -p "$BK/$(dirname "$f")"; cp "$f" "$BK/$f"; fi; done
grep -qx "$BK/" .git/info/exclude 2>/dev/null || echo "$BK/" >> .git/info/exclude
cp -R "$SRC/." .
echo "4/5 Vérifications…"; bad=0
chk(){ if grep -q "$2" "$1" 2>/dev/null; then echo "   OK    $1"; else echo "   ERREUR $1 ne contient pas « $2 »"; bad=1; fi; }
chk server.js 'api/fund'
chk server.js 'api/email-diag'
chk server.js 'api/services'
chk routes/walletOps.js 'FUND_ROUTER'
chk routes/walletOps.js 'paymentSafetyGate'
chk lib/fundManager.js 'chooseRoute'
chk public/omnicheck.html 'fmLoad'
chk public/omnicheck.html 'mdStatus'
chk public/omnicheck.html 'paymentRef'
if command -v node >/dev/null 2>&1; then for f in server.js routes/fundManager.js routes/walletOps.js lib/fundManager.js; do node --check "$f" || bad=1; done; echo "   OK    syntaxe JavaScript"; fi
if [ "$bad" = 1 ]; then echo "ARRÊT : une vérification a échoué, rien n'a été envoyé."; exit 1; fi
echo "5/5 Enregistrement et envoi…"
(cd "$SRC" && find . -type f) | while read -r f; do git add "$f"; done
git commit -m "OMNIPAY v20 : gestionnaire de fonds et de risque (couverture, voies recommandées, rééquilibrage)" || echo "   (rien de nouveau)"
git push origin main
echo "TERMINÉ. Attendez 2-3 minutes (Render), puis rechargez OMNICHECK avec Cmd+Maj+R."

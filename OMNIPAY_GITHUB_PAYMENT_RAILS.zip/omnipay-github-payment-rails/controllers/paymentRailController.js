"use strict";
const {listProviders,getProvider}=require("../services/providerRegistry.js");
const {createOrder,getOrder,processEvent}=require("../services/paymentRailService.js");
async function providers(req,res){return res.json({providers:listProviders()})}
async function create(req,res){try{return res.status(201).json(await createOrder({userId:req.user.userId,...req.body}))}catch(e){return res.status(400).json({error:e.message})}}
async function read(req,res){try{const order=await getOrder({orderId:req.params.orderId,userId:req.user.userId});return order?res.json({order}):res.status(404).json({error:"Ordre introuvable."})}catch{return res.status(500).json({error:"Erreur serveur."})}}
async function webhook(req,res){try{const provider=getProvider(req.params.provider),rawBody=Buffer.isBuffer(req.body)?req.body.toString("utf8"):JSON.stringify(req.body),event=await provider.verifyWebhook({rawBody,headers:req.headers});return res.json({success:true,...await processEvent({providerId:req.params.provider,event})})}catch(e){return res.status(400).json({success:false,error:e.message})}}
module.exports={providers,create,read,webhook};

# OMNIPAY Payment Rails — GitHub Ready

Architecture de collecte et de versement par opérateur avec un compte de règlement OMNIPAY par rail.

## Principe

1. OMNIPAY crée un `order_id` unique.
2. Le client choisit MTN, Moov, Celtiis ou Ecobank/PI-SPI.
3. Le backend appelle uniquement l’API officielle du rail activé.
4. Le client autorise le paiement dans l’application ou le canal officiel du prestataire.
5. OMNIPAY attend le webhook ou vérifie le statut côté serveur.
6. Le ledger passe l’ordre de `pending` à `completed` une seule fois.
7. OMNIPAY génère le reçu.

Aucun identifiant, endpoint, lien profond ou secret opérateur n’est inventé. Les connecteurs restent désactivés tant que les paramètres officiels ne sont pas fournis.

## Fichiers

- `db/migrations/20261009_payment_rails.sql`
- `lib/paymentStates.js`
- `lib/paymentSecurity.js`
- `services/providerRegistry.js`
- `services/ledgerService.js`
- `services/paymentRailService.js`
- `providers/*.js`
- `controllers/paymentRailController.js`
- `routes/paymentRails.js`
- `public/payment-rails.js`
- `.env.payment-rails.example`

## Branchement dans server.js

Avant le gestionnaire 404:

```js
const paymentRailsRoutes = require("./routes/paymentRails.js");
app.use("/api/payment-rails", paymentRailsRoutes);
```

Important: les webhooks qui exigent le corps brut doivent être montés avant `express.json()`, selon la spécification officielle du prestataire.

## Vérification

```bash
node --check lib/paymentStates.js
node --check lib/paymentSecurity.js
node --check services/providerRegistry.js
node --check services/ledgerService.js
node --check services/paymentRailService.js
node --check controllers/paymentRailController.js
node --check routes/paymentRails.js
node --check public/payment-rails.js
```

## API

- `GET /api/payment-rails/providers`
- `POST /api/payment-rails/orders`
- `GET /api/payment-rails/orders/:orderId`
- `POST /api/payment-rails/webhooks/:provider`

## Sécurité

- Secrets uniquement dans Render Environment.
- Aucun secret dans GitHub ou `public/`.
- Crédit du wallet uniquement après confirmation serveur vérifiée.
- Idempotence et événements uniques pour empêcher les doubles crédits.
- Revue manuelle au-dessus du seuil configuré.

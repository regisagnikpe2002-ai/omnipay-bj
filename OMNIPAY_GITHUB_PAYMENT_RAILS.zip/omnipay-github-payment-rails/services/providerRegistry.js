"use strict";
const providers={mtn:require("../providers/mtnMomo.js"),moov:require("../providers/moov.js"),celtiis:require("../providers/celtiis.js"),ecobank:require("../providers/ecobank.js"),pispi:require("../providers/piSpi.js")};
function getProvider(id,{requireEnabled=true}={}){const p=providers[String(id||"").toLowerCase()];if(!p)throw new Error("Prestataire inconnu.");if(requireEnabled&&!p.isEnabled())throw new Error("Prestataire non activé avec des accès officiels.");return p}
function listProviders(){return Object.values(providers).map(p=>({id:p.id,label:p.label,enabled:p.isEnabled(),capabilities:p.capabilities,customerAppUrl:p.customerAppUrl()}))}
module.exports={getProvider,listProviders};

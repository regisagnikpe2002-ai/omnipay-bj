"use strict";
const crypto=require("crypto");
const {neon}=require("@neondatabase/serverless");
function sql(){if(!process.env.DATABASE_URL)throw new Error("DATABASE_URL manquante.");return neon(process.env.DATABASE_URL)}
async function postBalanced({orderId,currency,entries}){const debit=entries.filter(e=>e.side==="debit").reduce((s,e)=>s+Number(e.amount),0),credit=entries.filter(e=>e.side==="credit").reduce((s,e)=>s+Number(e.amount),0);if(Math.abs(debit-credit)>0.001)throw new Error("Ledger déséquilibré.");const db=sql();await db.transaction(entries.map(e=>db`INSERT INTO ledger_entries(id,order_id,account_code,side,amount,currency,description) VALUES(${crypto.randomUUID()},${orderId},${e.accountCode},${e.side},${Number(e.amount).toFixed(2)},${currency},${e.description||null})`))}
function payinEntries({provider,userId,gross,fee,net}){return [{accountCode:`clearing:${provider}`,side:"debit",amount:gross,description:"Fonds reçus du rail"},{accountCode:`wallet:${userId}`,side:"credit",amount:net,description:"Crédit wallet client"},...(Number(fee)>0?[{accountCode:"revenue:fees",side:"credit",amount:fee,description:"Commission OMNIPAY"}]:[])]}
module.exports={postBalanced,payinEntries};

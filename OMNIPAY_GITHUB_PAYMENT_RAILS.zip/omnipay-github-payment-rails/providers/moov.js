"use strict";
const {createOfficialProvider}=require("./baseProvider.js");
module.exports=createOfficialProvider({id:"moov",label:"Moov Money",capabilities:["payin","payout"],enabled:()=>process.env.MOOV_ENABLED==="true"&&!!process.env.MOOV_BASE_URL&&!!process.env.MOOV_CLIENT_ID&&!!process.env.MOOV_CLIENT_SECRET,customerAppUrl:()=>process.env.MOOV_CUSTOMER_APP_URL});

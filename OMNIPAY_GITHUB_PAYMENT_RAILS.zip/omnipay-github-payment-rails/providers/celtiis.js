"use strict";
const {createOfficialProvider}=require("./baseProvider.js");
module.exports=createOfficialProvider({id:"celtiis",label:"Celtiis Cash",capabilities:["payin","payout"],enabled:()=>process.env.CELTIIS_ENABLED==="true"&&!!process.env.CELTIIS_BASE_URL&&!!process.env.CELTIIS_CLIENT_ID&&!!process.env.CELTIIS_CLIENT_SECRET,customerAppUrl:()=>process.env.CELTIIS_CUSTOMER_APP_URL});

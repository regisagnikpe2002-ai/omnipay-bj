"use strict";
const {createOfficialProvider}=require("./baseProvider.js");
module.exports=createOfficialProvider({id:"ecobank",label:"Ecobank",capabilities:["payin","payout","transfer"],enabled:()=>process.env.ECOBANK_ENABLED==="true"&&!!process.env.ECOBANK_BASE_URL&&!!process.env.ECOBANK_CLIENT_ID&&!!process.env.ECOBANK_CLIENT_SECRET,customerAppUrl:()=>process.env.ECOBANK_CUSTOMER_APP_URL});

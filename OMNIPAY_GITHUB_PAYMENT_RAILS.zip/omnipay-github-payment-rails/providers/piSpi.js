"use strict";
const {createOfficialProvider}=require("./baseProvider.js");
module.exports=createOfficialProvider({id:"pispi",label:"PI-SPI",capabilities:["payin","payout","transfer"],enabled:()=>process.env.PISPI_ENABLED==="true"&&!!process.env.PISPI_BASE_URL&&!!process.env.PISPI_CLIENT_ID&&!!process.env.PISPI_CLIENT_SECRET&&!!process.env.PISPI_MTLS_CERT_PATH&&!!process.env.PISPI_MTLS_KEY_PATH,customerAppUrl:()=>process.env.PISPI_CUSTOMER_APP_URL});

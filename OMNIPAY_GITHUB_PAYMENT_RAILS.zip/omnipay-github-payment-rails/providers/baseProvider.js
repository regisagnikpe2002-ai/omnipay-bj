"use strict";
function createOfficialProvider({id,label,capabilities,enabled,customerAppUrl}){
 return {id,label,capabilities,isEnabled:enabled,customerAppUrl:()=>customerAppUrl?.()||null,
  async initiate(){throw new Error(`${label}: implémentation officielle non configurée.`)},
  async verifyWebhook(){throw new Error(`${label}: webhook officiel non configuré.`)},
  async queryStatus(){throw new Error(`${label}: consultation de statut non configurée.`)}
 };
}
module.exports={createOfficialProvider};

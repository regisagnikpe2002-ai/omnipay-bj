"use strict";
const {createOfficialProvider}=require("./baseProvider.js");
module.exports=createOfficialProvider({id:"mtn",label:"MTN MoMo",capabilities:["payin","payout"],enabled:()=>process.env.MTN_MOMO_ENABLED==="true"&&!!process.env.MTN_MOMO_BASE_URL&&!!process.env.MTN_MOMO_SUBSCRIPTION_KEY&&!!process.env.MTN_MOMO_API_USER&&!!process.env.MTN_MOMO_API_KEY,customerAppUrl:()=>process.env.MTN_MOMO_CUSTOMER_APP_URL});

"use strict";

const crypto = require("crypto");
const { neon } = require("@neondatabase/serverless");

const sql = () => {
  const url = String(process.env.DATABASE_URL || "").trim();
  if (!url) throw new Error("DATABASE_URL manquante.");
  return neon(url);
};

const clean = (value, max = 160) =>
  String(value == null ? "" : value)
    .replace(/[<>]/g, "")
    .trim()
    .slice(0, max);

const positiveMoney = (value, label) => {
  const amount = Math.round(Number(value));
  if (!Number.isSafeInteger(amount) || amount <= 0) {
    throw new Error(`${label} invalide.`);
  }
  return amount;
};

const nonNegativeMoney = (value, label) => {
  const amount = Math.round(Number(value));
  if (!Number.isSafeInteger(amount) || amount < 0) {
    throw new Error(`${label} invalide.`);
  }
  return amount;
};

const requireUuid = (value, label) => {
  const id = clean(value, 36);
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(id)) {
    throw new Error(`${label} invalide.`);
  }
  return id;
};

const requireOperationKey = (value) => {
  const key = clean(value, 160);
  if (key.length < 6) throw new Error("Cle d'idempotence requise.");
  return key;
};

const requireSettlementRef = (value) => {
  const ref = clean(value, 160);
  if (ref.length < 6) throw new Error("Reference reelle de reglement requise.");
  return ref;
};

/**
 * IN: credite le miroir client uniquement apres confirmation externe reelle.
 * L'unicite est garantie par ledger_operation_keys.operation_key.
 */
async function creditPayin({
  userId,
  amount,
  provider,
  providerRef,
  idempotencyKey,
  confirmed
}) {
  if (confirmed !== true) {
    throw new Error("Depot non confirme par le canal externe.");
  }

  const q = sql();
  const uid = requireUuid(userId, "Utilisateur");
  const value = positiveMoney(amount, "Montant");
  const externalRef = requireSettlementRef(providerRef);
  const key = requireOperationKey(idempotencyKey);
  const source = clean(provider, 30) || "supervised";

  try {
    const rows = await q`
      WITH w AS (
        UPDATE wallets
        SET balance = balance + ${value}, updated_at = now()
        WHERE user_id = ${uid}::uuid
        RETURNING id, balance, reserved_balance
      ),
      op AS (
        INSERT INTO ledger_operation_keys (operation_key, operation_type)
        SELECT ${key}, 'PAYIN' FROM w
        RETURNING operation_key
      ),
      t AS (
        INSERT INTO transactions (
          wallet_id, type, amount, balance_after, status,
          provider, provider_ref, idempotency_key, metadata
        )
        SELECT w.id, 'deposit', ${value}, w.balance, 'completed',
               ${source}, ${externalRef}, ${key},
               jsonb_build_object(
                 'ledgerType', 'PAYIN',
                 'mirrored', true,
                 'externalConfirmed', true
               )
        FROM w JOIN op ON true
        RETURNING id, wallet_id
      ),
      linked AS (
        UPDATE ledger_operation_keys
        SET transaction_id = t.id
        FROM t
        WHERE operation_key = ${key}
        RETURNING operation_key
      )
      SELECT t.id AS transaction_id,
             w.balance,
             w.reserved_balance,
             w.balance - w.reserved_balance AS available_balance
      FROM t JOIN w ON true JOIN linked ON true
    `;

    if (!rows.length) throw new Error("Wallet introuvable.");
    return {
      transactionId: rows[0].transaction_id,
      balance: Number(rows[0].balance),
      reservedBalance: Number(rows[0].reserved_balance),
      availableBalance: Number(rows[0].available_balance)
    };
  } catch (error) {
    if (error && error.code === "23505") {
      throw new Error("Depot deja traite.");
    }
    throw error;
  }
}

/**
 * OUT etape 1: reserve montant + frais sans diminuer le solde comptable.
 */
async function reserveWithdrawal({
  userId,
  amount,
  fee,
  provider,
  destination,
  idempotencyKey
}) {
  const q = sql();
  const uid = requireUuid(userId, "Utilisateur");
  const payout = positiveMoney(amount, "Montant");
  const commission = nonNegativeMoney(fee, "Frais");
  const total = payout + commission;
  const key = requireOperationKey(idempotencyKey || `wd-${crypto.randomUUID()}`);
  const route = clean(provider, 30) || "manual";
  const target = clean(destination, 200);
  if (target.length < 5) throw new Error("Destination invalide.");

  try {
    const rows = await q`
      WITH w AS (
        UPDATE wallets
        SET reserved_balance = reserved_balance + ${total}, updated_at = now()
        WHERE user_id = ${uid}::uuid
          AND balance - reserved_balance >= ${total}
        RETURNING id, balance, reserved_balance
      ),
      op AS (
        INSERT INTO ledger_operation_keys (operation_key, operation_type)
        SELECT ${key}, 'PAYOUT_RESERVE' FROM w
        RETURNING operation_key
      ),
      t AS (
        INSERT INTO transactions (
          wallet_id, type, amount, balance_after, status,
          provider, provider_ref, idempotency_key, metadata
        )
        SELECT w.id, 'withdrawal', ${payout}, w.balance, 'pending',
               ${route}, ${target}, ${key},
               jsonb_build_object(
                 'fee', ${commission},
                 'reservedTotal', ${total},
                 'ledgerType', 'PAYOUT_RESERVED'
               )
        FROM w JOIN op ON true
        RETURNING id, wallet_id
      ),
      r AS (
        INSERT INTO withdrawal_reservations (
          wallet_id, transaction_id, amount, fee
        )
        SELECT t.wallet_id, t.id, ${payout}, ${commission}
        FROM t
        RETURNING id
      ),
      linked AS (
        UPDATE ledger_operation_keys
        SET transaction_id = t.id
        FROM t
        WHERE operation_key = ${key}
        RETURNING operation_key
      )
      SELECT t.id AS transaction_id,
             r.id AS reservation_id,
             w.balance,
             w.reserved_balance,
             w.balance - w.reserved_balance AS available_balance
      FROM t JOIN r ON true JOIN w ON true JOIN linked ON true
    `;

    if (!rows.length) {
      throw new Error("Solde disponible insuffisant ou wallet introuvable.");
    }

    return {
      transactionId: rows[0].transaction_id,
      reservationId: rows[0].reservation_id,
      balance: Number(rows[0].balance),
      reservedBalance: Number(rows[0].reserved_balance),
      availableBalance: Number(rows[0].available_balance)
    };
  } catch (error) {
    if (error && error.code === "23505") {
      throw new Error("Retrait deja cree.");
    }
    throw error;
  }
}

/**
 * OUT etape 2 succes: consomme la reservation, debite le client,
 * acquiert la commission et enregistre la preuve externe unique.
 */
async function completeWithdrawal({
  transactionId,
  settlementRef,
  channel = "pispi"
}) {
  const q = sql();
  const txId = requireUuid(transactionId, "Transaction");
  const ref = requireSettlementRef(settlementRef);
  const settlementChannel = clean(channel, 30) || "pispi";

  try {
    const rows = await q`
      WITH r AS (
        UPDATE withdrawal_reservations wr
        SET status = 'completed',
            settlement_channel = ${settlementChannel},
            settlement_ref = ${ref},
            completed_at = now()
        FROM transactions tx
        WHERE wr.transaction_id = ${txId}::uuid
          AND wr.status = 'reserved'
          AND tx.id = wr.transaction_id
          AND tx.type = 'withdrawal'
          AND tx.status IN ('pending', 'processing', 'failed')
        RETURNING wr.wallet_id, wr.transaction_id, wr.amount, wr.fee
      ),
      w AS (
        UPDATE wallets
        SET balance = balance - (r.amount + r.fee),
            reserved_balance = reserved_balance - (r.amount + r.fee),
            updated_at = now()
        FROM r
        WHERE wallets.id = r.wallet_id
          AND wallets.balance >= r.amount + r.fee
          AND wallets.reserved_balance >= r.amount + r.fee
        RETURNING wallets.id,
                  wallets.balance,
                  wallets.reserved_balance,
                  r.transaction_id,
                  r.fee
      ),
      t AS (
        UPDATE transactions
        SET status = 'completed',
            balance_after = w.balance,
            metadata = coalesce(metadata, '{}'::jsonb) ||
              jsonb_build_object(
                'settlement', jsonb_build_object(
                  'channel', ${settlementChannel},
                  'reference', ${ref},
                  'confirmedAt', now()::text,
                  'confirmedBy', 'admin'
                )
              )
        FROM w
        WHERE transactions.id = w.transaction_id
        RETURNING transactions.id,
                  transactions.wallet_id,
                  transactions.idempotency_key
      ),
      c AS (
        INSERT INTO platform_accounts (
          code, label, currency, balance, updated_at
        )
        SELECT 'COMMISSION_XOF',
               'Commissions acquises OMNIPAY',
               'XOF',
               w.fee,
               now()
        FROM w JOIN t ON true
        ON CONFLICT (code) DO UPDATE
          SET balance = platform_accounts.balance + EXCLUDED.balance,
              updated_at = now()
        RETURNING balance
      ),
      ct AS (
        INSERT INTO transactions (
          wallet_id, type, amount, balance_after, status,
          provider, provider_ref, idempotency_key, metadata
        )
        SELECT t.wallet_id,
               'commission',
               w.fee,
               w.balance,
               'completed',
               'internal',
               ${ref},
               t.idempotency_key || '-fee',
               jsonb_build_object('ledgerType', 'COMMISSION_ACQUIRED')
        FROM t JOIN w ON true
        RETURNING id
      )
      SELECT t.id AS transaction_id,
             w.balance,
             w.reserved_balance,
             w.balance - w.reserved_balance AS available_balance,
             c.balance AS commission_balance
      FROM t JOIN w ON true JOIN c ON true JOIN ct ON true
    `;

    if (!rows.length) {
      throw new Error("Retrait introuvable, non reservable ou deja traite.");
    }

    return {
      transactionId: rows[0].transaction_id,
      balance: Number(rows[0].balance),
      reservedBalance: Number(rows[0].reserved_balance),
      availableBalance: Number(rows[0].available_balance),
      commissionBalance: Number(rows[0].commission_balance)
    };
  } catch (error) {
    if (error && error.code === "23505") {
      throw new Error("Reference de reglement deja utilisee.");
    }
    throw error;
  }
}

/**
 * OUT etape 2 echec: libere seulement la reservation.
 * Le solde comptable du client ne change pas et aucune commission n'est acquise.
 */
async function releaseWithdrawal({ transactionId, note = "Retrait annule" }) {
  const q = sql();
  const txId = requireUuid(transactionId, "Transaction");
  const releaseNote = clean(note, 200) || "Retrait annule";

  const rows = await q`
    WITH r AS (
      UPDATE withdrawal_reservations wr
      SET status = 'released', released_at = now()
      FROM transactions tx
      WHERE wr.transaction_id = ${txId}::uuid
        AND wr.status = 'reserved'
        AND tx.id = wr.transaction_id
        AND tx.type = 'withdrawal'
        AND tx.status IN ('pending', 'processing', 'failed')
      RETURNING wr.wallet_id, wr.transaction_id, wr.amount, wr.fee
    ),
    w AS (
      UPDATE wallets
      SET reserved_balance = reserved_balance - (r.amount + r.fee),
          updated_at = now()
      FROM r
      WHERE wallets.id = r.wallet_id
        AND wallets.reserved_balance >= r.amount + r.fee
      RETURNING wallets.balance,
                wallets.reserved_balance,
                r.transaction_id
    ),
    t AS (
      UPDATE transactions
      SET status = 'failed',
          metadata = coalesce(metadata, '{}'::jsonb) ||
            jsonb_build_object(
              'releaseNote', ${releaseNote},
              'releasedAt', now()::text
            )
      FROM w
      WHERE transactions.id = w.transaction_id
      RETURNING transactions.id
    )
    SELECT t.id AS transaction_id,
           w.balance,
           w.reserved_balance,
           w.balance - w.reserved_balance AS available_balance
    FROM t JOIN w ON true
  `;

  if (!rows.length) {
    throw new Error("Reservation introuvable ou deja liberee.");
  }

  return {
    transactionId: rows[0].transaction_id,
    balance: Number(rows[0].balance),
    reservedBalance: Number(rows[0].reserved_balance),
    availableBalance: Number(rows[0].available_balance)
  };
}

async function getWalletPosition(userId) {
  const q = sql();
  const uid = requireUuid(userId, "Utilisateur");
  const rows = await q`
    SELECT id,
           balance::float AS balance,
           reserved_balance::float AS reserved_balance,
           (balance - reserved_balance)::float AS available_balance,
           currency,
           status
    FROM wallets
    WHERE user_id = ${uid}::uuid
    LIMIT 1
  `;
  return rows[0] || null;
}

module.exports = {
  creditPayin,
  reserveWithdrawal,
  completeWithdrawal,
  releaseWithdrawal,
  getWalletPosition
};

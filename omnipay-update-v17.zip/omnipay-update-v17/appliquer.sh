#!/bin/bash
# OMNIPAY v17 — Rapprochement Mobile Money (MTN · Moov · Celtiis · PI-SPI). À lancer DEPUIS le dossier omnipay-bj.
set -e
echo "OMNIPAY — paquet v17 (choix de la méthode de recharge, nouvelle connexion, accueil par groupes, demandes de paiement QR, rapprochement par lot, lien dans les e-mails OTP)"
SRC="$(cd "$(dirname "$0")" && pwd)/files"
if [ ! -f server.js ] || [ ! -d routes ] || [ ! -d public ]; then echo "ERREUR : lancez ce script depuis le dossier omnipay-bj."; exit 1; fi
echo "1/5 Synchronisation avec GitHub…"; git pull --rebase --autostash origin main
echo "2/5 Copie des fichiers…"
BK="_sauvegarde_avant_v17"; mkdir -p "$BK"; (cd "$SRC" && find . -type f) | while read -r f; do [ -f "$f" ] && { mkdir -p "$BK/$(dirname "$f")"; cp "$f" "$BK/$f"; }; done
grep -qx "$BK/" .git/info/exclude 2>/dev/null || echo "$BK/" >> .git/info/exclude
cp -R "$SRC/." .
echo "3/5 Vérifications…"; bad=0
chk(){ if grep -q "$2" "$1" 2>/dev/null; then echo "   OK    $1"; else echo "   ERREUR $1 ne contient pas « $2 »"; bad=1; fi; }
chk routes/channels.js '/record-batch'
chk routes/channels.js '"/reconcile"'
chk public/omnicheck.html 'rcRead'
chk public/omnicheck.html 'loadSup'
chk public/omnicheck.html 'openCash\|loadCash'
chk routes/payRequests.js 'pay_requests'
chk server.js 'api/pay'
chk server.js 'api/cashdesk'
chk public/index.html 'id="splash"'
chk public/index.html 'applyPendingPay'
chk public/index.html 'openDep'
chk services/emailService.js 'Ouvrir OMNIPAY'
[ -f public/omnipay-splash.jpg ] && [ -f public/omnipay-hero.jpg ] || { echo '   ERREUR images manquantes'; bad=1; }
if command -v node >/dev/null 2>&1; then for f in server.js routes/channels.js routes/payRequests.js services/emailService.js; do node --check "$f" || bad=1; done; echo "   OK    syntaxe JavaScript"; fi
if [ "$bad" = 1 ]; then echo "ARRÊT : une vérification a échoué, rien n'a été envoyé."; exit 1; fi
echo "4/5 Enregistrement…"
(cd "$SRC" && find . -type f) | while read -r f; do git add "$f"; done
git commit -m "OMNIPAY v17 : choix de la méthode de recharge, nouvelle connexion, accueil par groupes, demandes de paiement QR, rapprochement par lot, lien dans les e-mails OTP" || echo "   (rien de nouveau)"
echo "5/5 Envoi vers GitHub…"; git push origin main
echo "TERMINÉ. Ouvrez la page de connexion (rechargez avec Ctrl+Maj+R), puis OMNICHECK : carte « Rapprochement Mobile Money »."

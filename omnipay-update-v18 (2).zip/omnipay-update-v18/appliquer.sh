#!/bin/bash
# OMNIPAY v18 — RÉPARATION + branchements. À lancer DEPUIS le dossier omnipay-bj.
# Répare ce que le paquet v17 avait écrasé (contrôle de paiement réel dans OMNICHECK, inspecteur de schéma) et corrige le « marquer payé » (erreur SQL).
set -e
echo "OMNIPAY — paquet v18 (réparation + portail de sécurité + catalogue des services)"
SRC="$(cd "$(dirname "$0")" && pwd)/files"
if [ ! -f server.js ] || [ ! -d routes ] || [ ! -d public ]; then echo "ERREUR : lancez ce script depuis le dossier omnipay-bj."; exit 1; fi
echo "1/5 Synchronisation avec GitHub…"; git pull --rebase --autostash origin main
echo "2/5 Contrôle : les fichiers locaux sont-ils ceux attendus ?"
bad=0
chkhash(){ cur="$(git hash-object "$1" 2>/dev/null || echo absent)"; if [ "$cur" = "$2" ]; then echo "   OK    $1"; else echo "   DIFFÉRENT $1 (modifié depuis la préparation de ce paquet)"; bad=1; fi; }
chkhash public/omnicheck.html 6a2d76aa8532231149d8ac16cfdb16f7fe31ce03
chkhash public/index.html 692134f769d8088140ade6ae3d43705708461801
chkhash server.js 605a52c38855199dddd940085eac68cb9e3eeaec
chkhash routes/schemaInspect.js f560cb86120c21fa0dc589e874f446eaa09fedb6
chkhash routes/walletOps.js 7e27eccbda6483640154b8fe75bc709584667137
chkhash routes/manualPayments.js 83232b28d1d4951abac209eead0f1976c8c6ca30
chkhash providers/piSpiSupervised.js 85dbde6f5c41b13d791a879d5e4b755d2df63cc0
if [ "$bad" = 1 ]; then echo "ARRÊT : un fichier a changé depuis (vous ou Copilot). Rien n'a été copié : envoyez-moi cet écran pour que je fusionne sans rien écraser."; exit 1; fi
echo "3/5 Copie des fichiers…"
BK="_sauvegarde_avant_v18"; mkdir -p "$BK"; (cd "$SRC" && find . -type f) | while read -r f; do [ -f "$f" ] && { mkdir -p "$BK/$(dirname "$f")"; cp "$f" "$BK/$f"; }; done
grep -qx "$BK/" .git/info/exclude 2>/dev/null || echo "$BK/" >> .git/info/exclude
cp -R "$SRC/." .
echo "4/5 Vérifications…"; bad=0
chk(){ if grep -q "$2" "$1" 2>/dev/null; then echo "   OK    $1"; else echo "   ERREUR $1 ne contient pas « $2 »"; bad=1; fi; }
chk public/omnicheck.html 'paymentRef'
chk public/omnicheck.html 'rcRead'
chk routes/walletOps.js 'paymentSafetyGate'
chk routes/walletOps.js '::text'
chk routes/manualPayments.js '::text'
chk routes/schemaInspect.js 'timingSafeEqual'
chk server.js 'api/schema-inspect'
chk server.js 'api/services'
chk public/index.html 'loadNet'
chk providers/piSpiSupervised.js '1ced2141'
if ! grep -q "sendBatch" public/omnicheck.html || grep -q 'onclick="paidSel()"' public/omnicheck.html; then echo "   ERREUR : le bouton « lot payé » est revenu dans OMNICHECK"; bad=1; fi
if command -v node >/dev/null 2>&1; then for f in server.js routes/schemaInspect.js routes/servicesCatalog.js routes/walletOps.js routes/manualPayments.js providers/piSpiSupervised.js; do node --check "$f" || bad=1; done; echo "   OK    syntaxe JavaScript"; fi
if [ "$bad" = 1 ]; then echo "ARRÊT : une vérification a échoué, rien n'a été envoyé."; exit 1; fi
echo "5/5 Enregistrement et envoi…"
(cd "$SRC" && find . -type f) | while read -r f; do git add "$f"; done
git commit -m "OMNIPAY v18 : répare OMNICHECK (référence de paiement réelle) et l'inspecteur de schéma, corrige le SQL du marquage payé, branche le portail de sécurité et le catalogue des services" || echo "   (rien de nouveau)"
git push origin main
echo "TERMINÉ. Attendez 2-3 minutes (Render), puis rechargez avec Cmd+Maj+R."

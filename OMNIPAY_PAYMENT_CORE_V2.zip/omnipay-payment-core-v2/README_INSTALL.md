# OMNIPAY Payment Core V2

Ce module ajoute une architecture de paiement multirail sans contourner les opérateurs.

## Principes

- Ledger central en partie double et append-only.
- Un `order_id` OMNIPAY unique par opération.
- Idempotence pour empêcher les doubles crédits.
- Statuts: `created`, `pending`, `processing`, `completed`, `failed`, `cancelled`, `refunded`, `manual_review`.
- Adaptateurs officiels séparés: Ecobank, PI-SPI, MTN MoMo, Celtiis.
- Aucun endpoint privé, aucune clé ou URL opérateur inventée.
- Tout rail reste désactivé tant que ses identifiants officiels ne sont pas présents.
- Approbation manuelle configurable au-dessus d'un seuil.

## Installation

1. Copier les dossiers dans la racine du projet OMNIPAY.
2. Exécuter la migration SQL `db/migrations/20261009_payment_core.sql` sur Neon.
3. Ajouter les variables de `.env.payment.example` dans Render, avec les valeurs officielles.
4. Monter la route webhook avant `express.json()` afin de préserver le corps brut signé, puis monter les autres routes avant le gestionnaire 404. Adaptez ce point à l’ordre exact de votre `server.js`:

```js
const paymentCoreRoutes = require("./routes/paymentCore.js");
app.use("/api/payment-core", paymentCoreRoutes);
```

5. Vérifier:

```bash
node --check services/paymentOrchestrator.js
node --check services/ledgerService.js
node --check routes/paymentCore.js
node --check controllers/paymentCoreController.js
```

## Routes

- `GET /api/payment-core/providers`
- `POST /api/payment-core/orders`
- `GET /api/payment-core/orders/:orderId`
- `POST /api/payment-core/webhooks/:provider`

Toutes les routes utilisateur nécessitent le middleware JWT existant. Les webhooks utilisent la vérification propre à chaque prestataire.

## Important

Un bouton de paiement ne doit être marqué actif que lorsque le partenaire a fourni des accès officiels et qu'un test sandbox a réussi. PI-SPI est destiné aux participants financiers autorisés; OMNIPAY doit passer par Ecobank ou un participant/partenaire autorisé tant qu'OMNIPAY n'est pas lui-même admis comme participant.

"use strict";
const { listProviders, getProvider } = require("../services/providerRegistry.js");
const { createOrder, getOrder, processVerifiedEvent } = require("../services/paymentOrchestrator.js");

async function providers(req,res){ return res.json({providers:listProviders()}); }
async function create(req,res){
  try { const result=await createOrder({userId:req.user.userId,...req.body}); return res.status(201).json(result); }
  catch(e){ return res.status(400).json({error:e.message}); }
}
async function read(req,res){
  try { const order=await getOrder({orderId:req.params.orderId,userId:req.user.userId}); if(!order)return res.status(404).json({error:"Ordre introuvable."}); return res.json({order}); }
  catch(e){ return res.status(500).json({error:"Erreur serveur."}); }
}
async function webhook(req,res){
  try { const provider=getProvider(req.params.provider); const rawBody=Buffer.isBuffer(req.body)?req.body.toString("utf8"):JSON.stringify(req.body); const event=await provider.verifyWebhook({rawBody,headers:req.headers}); const result=await processVerifiedEvent({providerName:req.params.provider,event}); return res.status(200).json({success:true,...result}); }
  catch(e){ return res.status(400).json({success:false,error:e.message}); }
}
module.exports={providers,create,read,webhook};

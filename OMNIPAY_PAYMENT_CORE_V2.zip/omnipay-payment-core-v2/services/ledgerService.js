"use strict";
const crypto = require("crypto");
const { neon } = require("@neondatabase/serverless");

function sqlClient() {
  if (!process.env.DATABASE_URL) throw new Error("DATABASE_URL manquante.");
  return neon(process.env.DATABASE_URL);
}

async function postBalancedEntries({ orderId, currency, entries }) {
  const debit = entries.filter(x => x.side === "debit").reduce((s,x) => s + Number(x.amount), 0);
  const credit = entries.filter(x => x.side === "credit").reduce((s,x) => s + Number(x.amount), 0);
  if (Math.abs(debit - credit) > 0.001) throw new Error("Écriture ledger déséquilibrée.");
  const sql = sqlClient();
  const queries = entries.map(e => sql`
    INSERT INTO ledger_entries (id, order_id, account_code, side, amount, currency, description)
    VALUES (${crypto.randomUUID()}, ${orderId}, ${e.accountCode}, ${e.side}, ${Number(e.amount).toFixed(2)}, ${currency}, ${e.description || null})
  `);
  await sql.transaction(queries);
}

function payinEntries({ userId, gross, fee, net }) {
  return [
    { accountCode: "provider_clearing", side: "debit", amount: gross, description: "Fonds reçus du prestataire" },
    { accountCode: `wallet:${userId}`, side: "credit", amount: net, description: "Crédit wallet client" },
    ...(Number(fee) > 0 ? [{ accountCode: "revenue:fees", side: "credit", amount: fee, description: "Commission OMNIPAY" }] : []),
  ];
}

module.exports = { postBalancedEntries, payinEntries };

"use strict";
const crypto = require("crypto");
const { neon } = require("@neondatabase/serverless");
const { getProvider } = require("./providerRegistry.js");
const { assertTransition, STATES } = require("../lib/paymentStates.js");
const { postBalancedEntries, payinEntries } = require("./ledgerService.js");

function sqlClient() { return neon(process.env.DATABASE_URL); }
function orderId() { return `OMP-${Date.now().toString(36).toUpperCase()}-${crypto.randomBytes(4).toString("hex").toUpperCase()}`; }

async function createOrder({ userId, provider: providerName, direction, amount, currency="XOF", beneficiary, metadata={} }) {
  const provider = getProvider(providerName);
  const gross = Number(amount);
  if (!Number.isFinite(gross) || gross <= 0) throw new Error("Montant invalide.");
  if (!provider.capabilities.includes(direction)) throw new Error("Opération non supportée par ce prestataire.");

  const fee = 0;
  const net = gross - fee;
  const highValue = gross >= Number(process.env.PAYMENT_HIGH_VALUE_XOF || 500000);
  const status = highValue ? STATES.MANUAL_REVIEW : STATES.CREATED;
  const id = crypto.randomUUID();
  const oid = orderId();
  const idem = crypto.randomUUID();
  const sql = sqlClient();

  await sql`
    INSERT INTO payment_orders (id, order_id, user_id, provider, direction, amount, currency, fee_amount, net_amount, status, idempotency_key, beneficiary, metadata)
    VALUES (${id}, ${oid}, ${userId}, ${providerName}, ${direction}, ${gross.toFixed(2)}, ${currency}, ${fee.toFixed(2)}, ${net.toFixed(2)}, ${status}, ${idem}, ${JSON.stringify(beneficiary || {})}::jsonb, ${JSON.stringify(metadata)}::jsonb)
  `;

  if (highValue) return { orderId: oid, status, requiresApproval: true };

  const initiated = await provider.initiate({ orderId: oid, direction, amount: gross, currency, beneficiary, metadata });
  await sql`
    UPDATE payment_orders SET status='pending', provider_ref=${initiated.providerRef || null}, metadata = metadata || ${JSON.stringify({ providerResponse: initiated.safeMetadata || {} })}::jsonb, updated_at=now()
    WHERE order_id=${oid} AND status='created'
  `;
  return { orderId: oid, status: "pending", nextAction: initiated.nextAction || null };
}

async function getOrder({ orderId: oid, userId }) {
  const sql = sqlClient();
  const rows = await sql`SELECT * FROM payment_orders WHERE order_id=${oid} AND user_id=${userId} LIMIT 1`;
  return rows[0] || null;
}

async function processVerifiedEvent({ providerName, event }) {
  const sql = sqlClient();
  const rows = await sql`SELECT * FROM payment_orders WHERE provider=${providerName} AND (provider_ref=${event.providerRef} OR order_id=${event.orderId}) LIMIT 1`;
  const order = rows[0];
  if (!order) throw new Error("Ordre OMNIPAY introuvable.");
  if (order.status === "completed") return { duplicate: true, orderId: order.order_id };
  assertTransition(order.status, event.status);

  const eventInsert = await sql`
    INSERT INTO payment_events (id, order_id, provider, event_type, event_id, payload_hash, payload)
    VALUES (${crypto.randomUUID()}, ${order.order_id}, ${providerName}, ${event.type}, ${event.eventId}, ${event.payloadHash}, ${JSON.stringify(event.payload)}::jsonb)
    ON CONFLICT (provider, event_id) DO NOTHING
    RETURNING id
  `;
  if (!eventInsert.length) return { duplicate: true, orderId: order.order_id };

  if (event.status === "completed" && order.direction === "payin") {
    await postBalancedEntries({
      orderId: order.order_id,
      currency: order.currency,
      entries: payinEntries({ userId: order.user_id, gross: order.amount, fee: order.fee_amount, net: order.net_amount }),
    });
  }

  await sql`UPDATE payment_orders SET status=${event.status}, updated_at=now() WHERE order_id=${order.order_id} AND status <> 'completed'`;
  return { duplicate: false, orderId: order.order_id, status: event.status };
}

module.exports = { createOrder, getOrder, processVerifiedEvent };

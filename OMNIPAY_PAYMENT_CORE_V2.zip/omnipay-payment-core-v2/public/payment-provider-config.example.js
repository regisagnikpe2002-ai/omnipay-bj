window.OMNIPAY_PROVIDERS = [
  { id:"ecobank", label:"Ecobank / PI-SPI", enabled:false, note:"Accès officiel à connecter" },
  { id:"mtn", label:"MTN MoMo", enabled:false, note:"Collection / Disbursement officiels requis" },
  { id:"celtiis", label:"Celtiis Cash", enabled:false, note:"API officielle requise" }
];

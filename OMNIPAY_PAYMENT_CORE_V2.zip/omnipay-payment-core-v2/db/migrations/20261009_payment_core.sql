BEGIN;

CREATE TABLE IF NOT EXISTS payment_orders (
  id uuid PRIMARY KEY,
  order_id varchar(64) NOT NULL UNIQUE,
  user_id uuid NOT NULL REFERENCES users(id),
  provider varchar(32) NOT NULL,
  direction varchar(16) NOT NULL CHECK (direction IN ('payin','payout','transfer')),
  amount numeric(18,2) NOT NULL CHECK (amount > 0),
  currency varchar(8) NOT NULL,
  fee_amount numeric(18,2) NOT NULL DEFAULT 0,
  net_amount numeric(18,2) NOT NULL,
  status varchar(24) NOT NULL DEFAULT 'created',
  provider_ref varchar(255),
  idempotency_key varchar(100) NOT NULL UNIQUE,
  beneficiary jsonb,
  metadata jsonb NOT NULL DEFAULT '{}'::jsonb,
  failure_reason text,
  approved_by uuid REFERENCES users(id),
  approved_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS payment_orders_user_idx ON payment_orders(user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS payment_orders_provider_ref_idx ON payment_orders(provider, provider_ref);

CREATE TABLE IF NOT EXISTS ledger_entries (
  id uuid PRIMARY KEY,
  order_id varchar(64) NOT NULL REFERENCES payment_orders(order_id),
  account_code varchar(64) NOT NULL,
  side varchar(6) NOT NULL CHECK (side IN ('debit','credit')),
  amount numeric(18,2) NOT NULL CHECK (amount > 0),
  currency varchar(8) NOT NULL,
  description text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS ledger_entries_order_idx ON ledger_entries(order_id);
CREATE INDEX IF NOT EXISTS ledger_entries_account_idx ON ledger_entries(account_code, created_at DESC);

CREATE TABLE IF NOT EXISTS payment_events (
  id uuid PRIMARY KEY,
  order_id varchar(64) NOT NULL REFERENCES payment_orders(order_id),
  provider varchar(32) NOT NULL,
  event_type varchar(64) NOT NULL,
  event_id varchar(255) NOT NULL,
  payload_hash varchar(64) NOT NULL,
  payload jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(provider, event_id)
);

COMMIT;

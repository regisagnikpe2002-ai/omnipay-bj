# OMNIPAY Secure Ledger Pack

Ce paquet adapte le principe de séparation des fonds à la pile réelle OMNIPAY : Node.js + PostgreSQL/Neon.

## Principe

- `wallets.balance` : dette comptable totale d'OMNIPAY envers le client.
- `wallets.reserved_balance` : retraits engagés mais non encore réglés.
- disponible client : `balance - reserved_balance`.
- `platform_accounts.COMMISSION_XOF` : commissions OMNIPAY acquises.
- une commission n'est acquise qu'après confirmation du paiement réel.

## Installation

1. Copier la migration vers `migrations/`.
2. Copier le service vers `services/`.
3. Exécuter la migration dans un environnement contrôlé.
4. Brancher les endpoints existants sur les quatre fonctions du service.
5. Ne pas importer de soldes depuis Excel sans rapprochement avec les fonds réels.

## Important

Ne pas créer `balance_commission` dans chaque utilisateur. La commission appartient à OMNIPAY et doit être centralisée dans un compte plateforme.
